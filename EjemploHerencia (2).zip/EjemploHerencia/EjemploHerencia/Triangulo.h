#pragma once
#include "Shape.h"
class Triangulo: public Shape {
public: 
	Triangulo(void);
	~Triangulo(void);
	int obtenerarea();

};

