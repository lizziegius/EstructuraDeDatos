#include "StdAfx.h"
#include "Triangulo.h"
#include "Shape.h"


Triangulo::Triangulo(void)
{
}


Triangulo::~Triangulo(void)
{
}

int Triangulo::obtenerarea(){
	return((width*height)/2);
}
