#include "StdAfx.h"
#include "Shape.h"


 void Shape::setWidth(int w) {
         width = w;
      }
 void Shape::setHeight(int h) {
         height = h;
      }