// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Triangulo.h"
#include "conio.h"

using namespace std;

int main(void) {
	int area;
   Rectangulo Rect;
 
   Rect.setWidth(5);
   Rect.setHeight(7);
   Triangulo Tri;
   Tri.setHeight(4);
   Tri.setWidth(3);
   area=Tri.obtenerarea();
   cout<<"El area triangulo: "<<area;

   // Muestra el �rea de un rectangulo
   cout << "Area rectangulo: " << Rect.getArea() << endl;
   getch();
   return 0;
}